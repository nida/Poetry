package broken.tongue.letters.scattered;

import dot.dash.dot.Darkness;
import dot.dash.dot.Pauses.in;

public interface Passing {

	static void snores(in dots, in dashes) {

		Darkness.sayAs(Passing.class.getSimpleName());
		// System.out.print("Eternal ");

	}

}
